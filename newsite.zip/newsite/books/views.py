from django.views import generic
from .models import Book


class IndexView(generic.ListView):
    template_name = 'books/index.html'

    def get_queryset(self):
        return Book.objects.all()


class DetailsView(generic.DetailView):
    model = Book
    template_name = 'books/details.html'
